package br.com.testeprova.testeprova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteprovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
