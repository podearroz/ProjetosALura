package br.com.testeprova.testeprova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteprovaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteprovaApplication.class, args);
	}

}
